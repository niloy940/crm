
<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.create')); ?> <?php echo e(trans('cruds.identificationCard.title_singular')); ?>

    </div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route("admin.identification-cards.store")); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label class="required" for="product_id"><?php echo e(trans('cruds.identificationCard.fields.product')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('product') ? 'is-invalid' : ''); ?>" name="product_id" id="product_id" required>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e(old('product_id') == $id ? 'selected' : ''); ?>><?php echo e($entry); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('product')): ?>
                    <span class="text-danger"><?php echo e($errors->first('product')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.identificationCard.fields.product_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="quantity"><?php echo e(trans('cruds.identificationCard.fields.quantity')); ?></label>
                <input class="form-control <?php echo e($errors->has('quantity') ? 'is-invalid' : ''); ?>" type="number" name="quantity" id="quantity" value="<?php echo e(old('quantity', '')); ?>" step="0.001" required>
                <?php if($errors->has('quantity')): ?>
                    <span class="text-danger"><?php echo e($errors->first('quantity')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.identificationCard.fields.quantity_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="lot_id"><?php echo e(trans('cruds.identificationCard.fields.lot')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('lot') ? 'is-invalid' : ''); ?>" name="lot_id" id="lot_id" required>
                    <?php $__currentLoopData = $lots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e(old('lot_id') == $id ? 'selected' : ''); ?>><?php echo e($entry); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('lot')): ?>
                    <span class="text-danger"><?php echo e($errors->first('lot')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.identificationCard.fields.lot_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="int_lot"><?php echo e(trans('cruds.identificationCard.fields.int_lot')); ?></label>
                <input class="form-control <?php echo e($errors->has('int_lot') ? 'is-invalid' : ''); ?>" type="text" name="int_lot" id="int_lot" value="<?php echo e(old('int_lot', '')); ?>" required>
                <?php if($errors->has('int_lot')): ?>
                    <span class="text-danger"><?php echo e($errors->first('int_lot')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.identificationCard.fields.int_lot_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="storage_cond"><?php echo e(trans('cruds.identificationCard.fields.storage_cond')); ?></label>
                <input class="form-control <?php echo e($errors->has('storage_cond') ? 'is-invalid' : ''); ?>" type="text" name="storage_cond" id="storage_cond" value="<?php echo e(old('storage_cond', 'Čuvati u magacinu,  na suvom i mračnom mestu.')); ?>" required>
                <?php if($errors->has('storage_cond')): ?>
                    <span class="text-danger"><?php echo e($errors->first('storage_cond')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.identificationCard.fields.storage_cond_helper')); ?></span>
            </div>
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    <?php echo e(trans('global.save')); ?>

                </button>
            </div>
        </form>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\crm\resources\views/admin/identificationCards/create.blade.php ENDPATH**/ ?>