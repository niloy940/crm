<?php

return [
    'previous' => '&laquo; Prethodni',
    'next'     => 'Sledeci &raquo;',
];
