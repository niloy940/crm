<?php

return [
    'failed'   => 'Ovi akreditivi se ne poklapaju sa našom evidencijom.',
    'password' => 'Navedena lozinka je netačna.',
    'throttle' => 'Previše pokušaja prijave. Molimo pokušajte ponovo za :seconds sekundi.',
];
