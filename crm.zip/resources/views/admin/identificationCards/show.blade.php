@extends('layouts.admin')
@section('content')

<div class="card">
    <div class="card-header">
        {{ trans('global.show') }} {{ trans('cruds.identificationCard.title') }}
    </div>

    <div class="card-body">
        <div class="form-group">
            <div class="form-group">
                <a class="btn btn-default" href="{{ route('admin.identification-cards.index') }}">
                    {{ trans('global.back_to_list') }}
                </a>
            </div>
            <table class="table table-bordered table-striped">
                <tbody>
                    <tr>
                        <th>
                            {{ trans('cruds.identificationCard.fields.id') }}
                        </th>
                        <td>
                            {{ $identificationCard->id }}
                        </td>
                    </tr>
                    <tr>
                        <th>
                            {{ trans('cruds.identificationCard.fields.product') }}
                        </th>
                        <td>
                            {{ $identificationCard->product->name ?? '' }}
                        </td>
                    </tr>
                    <tr>
                        <th>
                            {{ trans('cruds.identificationCard.fields.quantity') }}
                        </th>
                        <td>
                            {{ $identificationCard->quantity }}
                        </td>
                    </tr>
                    <tr>
                        <th>
                            {{ trans('cruds.identificationCard.fields.lot') }}
                        </th>
                        <td>
                            {{ $identificationCard->lot->lot ?? '' }}
                        </td>
                    </tr>
                    <tr>
                        <th>
                            {{ trans('cruds.identificationCard.fields.int_lot') }}
                        </th>
                        <td>
                            {{ $identificationCard->int_lot }}
                        </td>
                    </tr>
                    <tr>
                        <th>
                            {{ trans('cruds.identificationCard.fields.storage_cond') }}
                        </th>
                        <td>
                            {{ $identificationCard->storage_cond }}
                        </td>
                    </tr>
                </tbody>
            </table>
            <div class="form-group">
                <a class="btn btn-default" href="{{ route('admin.identification-cards.index') }}">
                    {{ trans('global.back_to_list') }}
                </a>
            </div>
        </div>
    </div>
</div>



@endsection