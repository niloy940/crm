
<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.show')); ?> <?php echo e(trans('cruds.packingList.title')); ?>

    </div>

    <div class="card-body">
        <div class="form-group">
            <div class="form-group">
                <a class="btn btn-default" href="<?php echo e(route('admin.packing-lists.index')); ?>">
                    <?php echo e(trans('global.back_to_list')); ?>

                </a>
            </div>
            <table class="table table-bordered table-striped">
                <tbody>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.packingList.fields.id')); ?>

                        </th>
                        <td>
                            <?php echo e($packingList->id); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.packingList.fields.client')); ?>

                        </th>
                        <td>
                            <?php echo e($packingList->client->company_name ?? ''); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.packingList.fields.product')); ?>

                        </th>
                        <td>
                            <?php echo e($packingList->product->name ?? ''); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.packingList.fields.quantity')); ?>

                        </th>
                        <td>
                            <?php echo e($packingList->quantity); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.packingList.fields.lot')); ?>

                        </th>
                        <td>
                            <?php $__currentLoopData = $packingList->lots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $lot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span class="label label-info"><?php echo e($lot->int_lot); ?></span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.packingList.fields.net_weight')); ?>

                        </th>
                        <td>
                            <?php echo e($packingList->net_weight); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.packingList.fields.bruto_weight')); ?>

                        </th>
                        <td>
                            <?php echo e($packingList->bruto_weight); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.packingList.fields.width')); ?>

                        </th>
                        <td>
                            <?php echo e($packingList->width); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.packingList.fields.height')); ?>

                        </th>
                        <td>
                            <?php echo e($packingList->height); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.packingList.fields.length')); ?>

                        </th>
                        <td>
                            <?php echo e($packingList->length); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.packingList.fields.user')); ?>

                        </th>
                        <td>
                            <?php echo e($packingList->user->name ?? ''); ?>

                        </td>
                    </tr>
                </tbody>
            </table>
            <div class="form-group">
                <a class="btn btn-default" href="<?php echo e(route('admin.packing-lists.index')); ?>">
                    <?php echo e(trans('global.back_to_list')); ?>

                </a>
            </div>
        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\crm\resources\views/admin/packingLists/show.blade.php ENDPATH**/ ?>