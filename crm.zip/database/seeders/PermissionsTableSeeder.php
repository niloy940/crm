<?php

namespace Database\Seeders;

use App\Models\Permission;
use Illuminate\Database\Seeder;

class PermissionsTableSeeder extends Seeder
{
    public function run()
    {
        $permissions = [
            [
                'id'    => 1,
                'title' => 'user_management_access',
            ],
            [
                'id'    => 2,
                'title' => 'permission_create',
            ],
            [
                'id'    => 3,
                'title' => 'permission_edit',
            ],
            [
                'id'    => 4,
                'title' => 'permission_show',
            ],
            [
                'id'    => 5,
                'title' => 'permission_delete',
            ],
            [
                'id'    => 6,
                'title' => 'permission_access',
            ],
            [
                'id'    => 7,
                'title' => 'role_create',
            ],
            [
                'id'    => 8,
                'title' => 'role_edit',
            ],
            [
                'id'    => 9,
                'title' => 'role_show',
            ],
            [
                'id'    => 10,
                'title' => 'role_delete',
            ],
            [
                'id'    => 11,
                'title' => 'role_access',
            ],
            [
                'id'    => 12,
                'title' => 'user_create',
            ],
            [
                'id'    => 13,
                'title' => 'user_edit',
            ],
            [
                'id'    => 14,
                'title' => 'user_show',
            ],
            [
                'id'    => 15,
                'title' => 'user_delete',
            ],
            [
                'id'    => 16,
                'title' => 'user_access',
            ],
            [
                'id'    => 17,
                'title' => 'basic_c_r_m_access',
            ],
            [
                'id'    => 18,
                'title' => 'crm_status_create',
            ],
            [
                'id'    => 19,
                'title' => 'crm_status_edit',
            ],
            [
                'id'    => 20,
                'title' => 'crm_status_show',
            ],
            [
                'id'    => 21,
                'title' => 'crm_status_delete',
            ],
            [
                'id'    => 22,
                'title' => 'crm_status_access',
            ],
            [
                'id'    => 23,
                'title' => 'crm_customer_create',
            ],
            [
                'id'    => 24,
                'title' => 'crm_customer_edit',
            ],
            [
                'id'    => 25,
                'title' => 'crm_customer_show',
            ],
            [
                'id'    => 26,
                'title' => 'crm_customer_delete',
            ],
            [
                'id'    => 27,
                'title' => 'crm_customer_access',
            ],
            [
                'id'    => 28,
                'title' => 'crm_note_create',
            ],
            [
                'id'    => 29,
                'title' => 'crm_note_edit',
            ],
            [
                'id'    => 30,
                'title' => 'crm_note_show',
            ],
            [
                'id'    => 31,
                'title' => 'crm_note_delete',
            ],
            [
                'id'    => 32,
                'title' => 'crm_note_access',
            ],
            [
                'id'    => 33,
                'title' => 'crm_document_create',
            ],
            [
                'id'    => 34,
                'title' => 'crm_document_edit',
            ],
            [
                'id'    => 35,
                'title' => 'crm_document_show',
            ],
            [
                'id'    => 36,
                'title' => 'crm_document_delete',
            ],
            [
                'id'    => 37,
                'title' => 'crm_document_access',
            ],
            [
                'id'    => 38,
                'title' => 'audit_log_show',
            ],
            [
                'id'    => 39,
                'title' => 'audit_log_access',
            ],
            [
                'id'    => 40,
                'title' => 'user_alert_create',
            ],
            [
                'id'    => 41,
                'title' => 'user_alert_show',
            ],
            [
                'id'    => 42,
                'title' => 'user_alert_delete',
            ],
            [
                'id'    => 43,
                'title' => 'user_alert_access',
            ],
            [
                'id'    => 44,
                'title' => 'task_management_access',
            ],
            [
                'id'    => 45,
                'title' => 'task_status_create',
            ],
            [
                'id'    => 46,
                'title' => 'task_status_edit',
            ],
            [
                'id'    => 47,
                'title' => 'task_status_show',
            ],
            [
                'id'    => 48,
                'title' => 'task_status_delete',
            ],
            [
                'id'    => 49,
                'title' => 'task_status_access',
            ],
            [
                'id'    => 50,
                'title' => 'task_tag_create',
            ],
            [
                'id'    => 51,
                'title' => 'task_tag_edit',
            ],
            [
                'id'    => 52,
                'title' => 'task_tag_show',
            ],
            [
                'id'    => 53,
                'title' => 'task_tag_delete',
            ],
            [
                'id'    => 54,
                'title' => 'task_tag_access',
            ],
            [
                'id'    => 55,
                'title' => 'task_create',
            ],
            [
                'id'    => 56,
                'title' => 'task_edit',
            ],
            [
                'id'    => 57,
                'title' => 'task_show',
            ],
            [
                'id'    => 58,
                'title' => 'task_delete',
            ],
            [
                'id'    => 59,
                'title' => 'task_access',
            ],
            [
                'id'    => 60,
                'title' => 'tasks_calendar_access',
            ],
            [
                'id'    => 61,
                'title' => 'team_create',
            ],
            [
                'id'    => 62,
                'title' => 'team_edit',
            ],
            [
                'id'    => 63,
                'title' => 'team_show',
            ],
            [
                'id'    => 64,
                'title' => 'team_delete',
            ],
            [
                'id'    => 65,
                'title' => 'team_access',
            ],
            [
                'id'    => 66,
                'title' => 'asset_management_access',
            ],
            [
                'id'    => 67,
                'title' => 'asset_category_create',
            ],
            [
                'id'    => 68,
                'title' => 'asset_category_edit',
            ],
            [
                'id'    => 69,
                'title' => 'asset_category_show',
            ],
            [
                'id'    => 70,
                'title' => 'asset_category_delete',
            ],
            [
                'id'    => 71,
                'title' => 'asset_category_access',
            ],
            [
                'id'    => 72,
                'title' => 'asset_location_create',
            ],
            [
                'id'    => 73,
                'title' => 'asset_location_edit',
            ],
            [
                'id'    => 74,
                'title' => 'asset_location_show',
            ],
            [
                'id'    => 75,
                'title' => 'asset_location_delete',
            ],
            [
                'id'    => 76,
                'title' => 'asset_location_access',
            ],
            [
                'id'    => 77,
                'title' => 'asset_status_create',
            ],
            [
                'id'    => 78,
                'title' => 'asset_status_edit',
            ],
            [
                'id'    => 79,
                'title' => 'asset_status_show',
            ],
            [
                'id'    => 80,
                'title' => 'asset_status_delete',
            ],
            [
                'id'    => 81,
                'title' => 'asset_status_access',
            ],
            [
                'id'    => 82,
                'title' => 'asset_create',
            ],
            [
                'id'    => 83,
                'title' => 'asset_edit',
            ],
            [
                'id'    => 84,
                'title' => 'asset_show',
            ],
            [
                'id'    => 85,
                'title' => 'asset_delete',
            ],
            [
                'id'    => 86,
                'title' => 'asset_access',
            ],
            [
                'id'    => 87,
                'title' => 'assets_history_access',
            ],
            [
                'id'    => 88,
                'title' => 'time_management_access',
            ],
            [
                'id'    => 89,
                'title' => 'time_work_type_create',
            ],
            [
                'id'    => 90,
                'title' => 'time_work_type_edit',
            ],
            [
                'id'    => 91,
                'title' => 'time_work_type_show',
            ],
            [
                'id'    => 92,
                'title' => 'time_work_type_delete',
            ],
            [
                'id'    => 93,
                'title' => 'time_work_type_access',
            ],
            [
                'id'    => 94,
                'title' => 'time_project_create',
            ],
            [
                'id'    => 95,
                'title' => 'time_project_edit',
            ],
            [
                'id'    => 96,
                'title' => 'time_project_show',
            ],
            [
                'id'    => 97,
                'title' => 'time_project_delete',
            ],
            [
                'id'    => 98,
                'title' => 'time_project_access',
            ],
            [
                'id'    => 99,
                'title' => 'time_entry_create',
            ],
            [
                'id'    => 100,
                'title' => 'time_entry_edit',
            ],
            [
                'id'    => 101,
                'title' => 'time_entry_show',
            ],
            [
                'id'    => 102,
                'title' => 'time_entry_delete',
            ],
            [
                'id'    => 103,
                'title' => 'time_entry_access',
            ],
            [
                'id'    => 104,
                'title' => 'time_report_create',
            ],
            [
                'id'    => 105,
                'title' => 'time_report_edit',
            ],
            [
                'id'    => 106,
                'title' => 'time_report_show',
            ],
            [
                'id'    => 107,
                'title' => 'time_report_delete',
            ],
            [
                'id'    => 108,
                'title' => 'time_report_access',
            ],
            [
                'id'    => 109,
                'title' => 'faq_management_access',
            ],
            [
                'id'    => 110,
                'title' => 'faq_category_create',
            ],
            [
                'id'    => 111,
                'title' => 'faq_category_edit',
            ],
            [
                'id'    => 112,
                'title' => 'faq_category_show',
            ],
            [
                'id'    => 113,
                'title' => 'faq_category_delete',
            ],
            [
                'id'    => 114,
                'title' => 'faq_category_access',
            ],
            [
                'id'    => 115,
                'title' => 'faq_question_create',
            ],
            [
                'id'    => 116,
                'title' => 'faq_question_edit',
            ],
            [
                'id'    => 117,
                'title' => 'faq_question_show',
            ],
            [
                'id'    => 118,
                'title' => 'faq_question_delete',
            ],
            [
                'id'    => 119,
                'title' => 'faq_question_access',
            ],
            [
                'id'    => 120,
                'title' => 'warehouse_access',
            ],
            [
                'id'    => 121,
                'title' => 'product_access',
            ],
            [
                'id'    => 122,
                'title' => 'products_list_create',
            ],
            [
                'id'    => 123,
                'title' => 'products_list_edit',
            ],
            [
                'id'    => 124,
                'title' => 'products_list_show',
            ],
            [
                'id'    => 125,
                'title' => 'products_list_delete',
            ],
            [
                'id'    => 126,
                'title' => 'products_list_access',
            ],
            [
                'id'    => 127,
                'title' => 'warehouses_list_create',
            ],
            [
                'id'    => 128,
                'title' => 'warehouses_list_edit',
            ],
            [
                'id'    => 129,
                'title' => 'warehouses_list_show',
            ],
            [
                'id'    => 130,
                'title' => 'warehouses_list_delete',
            ],
            [
                'id'    => 131,
                'title' => 'warehouses_list_access',
            ],
            [
                'id'    => 132,
                'title' => 'receipt_note_create',
            ],
            [
                'id'    => 133,
                'title' => 'receipt_note_edit',
            ],
            [
                'id'    => 134,
                'title' => 'receipt_note_show',
            ],
            [
                'id'    => 135,
                'title' => 'receipt_note_delete',
            ],
            [
                'id'    => 136,
                'title' => 'receipt_note_access',
            ],
            [
                'id'    => 137,
                'title' => 'identification_card_create',
            ],
            [
                'id'    => 138,
                'title' => 'identification_card_edit',
            ],
            [
                'id'    => 139,
                'title' => 'identification_card_show',
            ],
            [
                'id'    => 140,
                'title' => 'identification_card_delete',
            ],
            [
                'id'    => 141,
                'title' => 'identification_card_access',
            ],
            [
                'id'    => 142,
                'title' => 'delivery_note_create',
            ],
            [
                'id'    => 143,
                'title' => 'delivery_note_edit',
            ],
            [
                'id'    => 144,
                'title' => 'delivery_note_show',
            ],
            [
                'id'    => 145,
                'title' => 'delivery_note_delete',
            ],
            [
                'id'    => 146,
                'title' => 'delivery_note_access',
            ],
            [
                'id'    => 147,
                'title' => 'warehouse_transfer_create',
            ],
            [
                'id'    => 148,
                'title' => 'warehouse_transfer_edit',
            ],
            [
                'id'    => 149,
                'title' => 'warehouse_transfer_show',
            ],
            [
                'id'    => 150,
                'title' => 'warehouse_transfer_delete',
            ],
            [
                'id'    => 151,
                'title' => 'warehouse_transfer_access',
            ],
            [
                'id'    => 152,
                'title' => 'packing_list_create',
            ],
            [
                'id'    => 153,
                'title' => 'packing_list_edit',
            ],
            [
                'id'    => 154,
                'title' => 'packing_list_show',
            ],
            [
                'id'    => 155,
                'title' => 'packing_list_delete',
            ],
            [
                'id'    => 156,
                'title' => 'packing_list_access',
            ],
            [
                'id'    => 157,
                'title' => 'profile_password_edit',
            ],
        ];

        Permission::insert($permissions);
    }
}
