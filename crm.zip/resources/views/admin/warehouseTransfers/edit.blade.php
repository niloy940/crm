@extends('layouts.admin')
@section('content')

<div class="card">
    <div class="card-header">
        {{ trans('global.edit') }} {{ trans('cruds.warehouseTransfer.title_singular') }}
    </div>

    <div class="card-body">
        <form method="POST" action="{{ route("admin.warehouse-transfers.update", [$warehouseTransfer->id]) }}" enctype="multipart/form-data">
            @method('PUT')
            @csrf
            <div class="form-group">
                <label class="required" for="warehouse_from_id">{{ trans('cruds.warehouseTransfer.fields.warehouse_from') }}</label>
                <select class="form-control select2 {{ $errors->has('warehouse_from') ? 'is-invalid' : '' }}" name="warehouse_from_id" id="warehouse_from_id" required>
                    @foreach($warehouse_froms as $id => $entry)
                        <option value="{{ $id }}" {{ (old('warehouse_from_id') ? old('warehouse_from_id') : $warehouseTransfer->warehouse_from->id ?? '') == $id ? 'selected' : '' }}>{{ $entry }}</option>
                    @endforeach
                </select>
                @if($errors->has('warehouse_from'))
                    <span class="text-danger">{{ $errors->first('warehouse_from') }}</span>
                @endif
                <span class="help-block">{{ trans('cruds.warehouseTransfer.fields.warehouse_from_helper') }}</span>
            </div>
            <div class="form-group">
                <label class="required" for="warehouse_to_id">{{ trans('cruds.warehouseTransfer.fields.warehouse_to') }}</label>
                <select class="form-control select2 {{ $errors->has('warehouse_to') ? 'is-invalid' : '' }}" name="warehouse_to_id" id="warehouse_to_id" required>
                    @foreach($warehouse_tos as $id => $entry)
                        <option value="{{ $id }}" {{ (old('warehouse_to_id') ? old('warehouse_to_id') : $warehouseTransfer->warehouse_to->id ?? '') == $id ? 'selected' : '' }}>{{ $entry }}</option>
                    @endforeach
                </select>
                @if($errors->has('warehouse_to'))
                    <span class="text-danger">{{ $errors->first('warehouse_to') }}</span>
                @endif
                <span class="help-block">{{ trans('cruds.warehouseTransfer.fields.warehouse_to_helper') }}</span>
            </div>
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    {{ trans('global.save') }}
                </button>
            </div>
        </form>
    </div>
</div>



@endsection