
<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.create')); ?> <?php echo e(trans('cruds.warehouseTransfer.title_singular')); ?>

    </div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route("admin.warehouse-transfers.store")); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label class="required" for="warehouse_from_id"><?php echo e(trans('cruds.warehouseTransfer.fields.warehouse_from')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('warehouse_from') ? 'is-invalid' : ''); ?>" name="warehouse_from_id" id="warehouse_from_id" required>
                    <?php $__currentLoopData = $warehouse_froms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e(old('warehouse_from_id') == $id ? 'selected' : ''); ?>><?php echo e($entry); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('warehouse_from')): ?>
                    <span class="text-danger"><?php echo e($errors->first('warehouse_from')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.warehouseTransfer.fields.warehouse_from_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="warehouse_to_id"><?php echo e(trans('cruds.warehouseTransfer.fields.warehouse_to')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('warehouse_to') ? 'is-invalid' : ''); ?>" name="warehouse_to_id" id="warehouse_to_id" required>
                    <?php $__currentLoopData = $warehouse_tos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e(old('warehouse_to_id') == $id ? 'selected' : ''); ?>><?php echo e($entry); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('warehouse_to')): ?>
                    <span class="text-danger"><?php echo e($errors->first('warehouse_to')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.warehouseTransfer.fields.warehouse_to_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="product_id"><?php echo e(trans('cruds.warehouseTransfer.fields.product')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('product') ? 'is-invalid' : ''); ?>" name="product_id" id="product_id" required>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e(old('product_id') == $id ? 'selected' : ''); ?>><?php echo e($entry); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('product')): ?>
                    <span class="text-danger"><?php echo e($errors->first('product')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.warehouseTransfer.fields.product_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="quantity"><?php echo e(trans('cruds.warehouseTransfer.fields.quantity')); ?></label>
                <input class="form-control <?php echo e($errors->has('quantity') ? 'is-invalid' : ''); ?>" type="number" name="quantity" id="quantity" value="<?php echo e(old('quantity', '')); ?>" step="0.001" required>
                <?php if($errors->has('quantity')): ?>
                    <span class="text-danger"><?php echo e($errors->first('quantity')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.warehouseTransfer.fields.quantity_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="user_id"><?php echo e(trans('cruds.warehouseTransfer.fields.user')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('user') ? 'is-invalid' : ''); ?>" name="user_id" id="user_id" required>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e(old('user_id') == $id ? 'selected' : ''); ?>><?php echo e($entry); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('user')): ?>
                    <span class="text-danger"><?php echo e($errors->first('user')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.warehouseTransfer.fields.user_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="user_received_id"><?php echo e(trans('cruds.warehouseTransfer.fields.user_received')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('user_received') ? 'is-invalid' : ''); ?>" name="user_received_id" id="user_received_id" required>
                    <?php $__currentLoopData = $user_receiveds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e(old('user_received_id') == $id ? 'selected' : ''); ?>><?php echo e($entry); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('user_received')): ?>
                    <span class="text-danger"><?php echo e($errors->first('user_received')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.warehouseTransfer.fields.user_received_helper')); ?></span>
            </div>
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    <?php echo e(trans('global.save')); ?>

                </button>
            </div>
        </form>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\crm\resources\views/admin/warehouseTransfers/create.blade.php ENDPATH**/ ?>