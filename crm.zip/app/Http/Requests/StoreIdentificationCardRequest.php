<?php

namespace App\Http\Requests;

use App\Models\IdentificationCard;
use Gate;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Response;

class StoreIdentificationCardRequest extends FormRequest
{
    public function authorize()
    {
        return Gate::allows('identification_card_create');
    }

    public function rules()
    {
        return [
            'product_id' => [
                'required',
                'integer',
            ],
            'quantity' => [
                'numeric',
                'required',
            ],
            'lot_id' => [
                'required',
                'integer',
            ],
            'int_lot' => [
                'string',
                'min:3',
                'max:27',
                'required',
            ],
            'storage_cond' => [
                'string',
                'min:3',
                'required',
            ],
        ];
    }
}
