<?php

return [
    'password' => 'Lozinke moraju imati bar 6 karaktera i da se poklapaju.',
    'reset'    => 'Lozinka je resetovana!',
    'sent'     => 'Poslali smo vam email sa linkom za resetovanje lozinke!',
    'token'    => 'Token za resetovanje lozinke je nevazeci.',
    'user'     => 'Ne mozemo naci korisnika sa tom email adresom.',
    'updated'  => 'Vasa lozinka je izmenjena!',
];
