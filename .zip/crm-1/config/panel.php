<?php

return [
    'date_format'         => 'd/m/Y',
    'time_format'         => 'H:i:s',
    'primary_language'    => 'sr',
    'available_languages' => [
        'sr' => 'Serbian (Latin)',
        'en' => 'English',
    ],
];
