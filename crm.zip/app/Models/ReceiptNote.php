<?php

namespace App\Models;

use \DateTimeInterface;
use App\Traits\Auditable;
use App\Traits\MultiTenantModelTrait;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class ReceiptNote extends Model
{
    use SoftDeletes;
    use MultiTenantModelTrait;
    use Auditable;
    use HasFactory;

    public const PRINT_SELECT = [
        'pdf' => 'PDF',
    ];

    public const SHIFT_SELECT = [
        '1' => 'Prva',
        '2' => 'Druga',
        '3' => 'Treća',
    ];

    public const QC_SELECT = [
        'ispravno'   => 'ispravno',
        'neispravno' => 'neispravno',
    ];

    public $table = 'receipt_notes';

    public static $searchable = [
        'lot',
        'int_lot',
    ];

    protected $dates = [
        'date',
        'created_at',
        'updated_at',
        'deleted_at',
    ];

    protected $fillable = [
        'client_id',
        'quantity',
        'lot',
        'int_lot',
        'warehouse_id',
        'qc',
        'shift',
        'date',
        'place',
        'driver',
        'id_driver',
        'registration',
        'created_at',
        'print',
        'updated_at',
        'deleted_at',
        'team_id',
    ];

    public function client()
    {
        return $this->belongsTo(CrmCustomer::class, 'client_id');
    }

    public function products()
    {
        return $this->belongsToMany(ProductsList::class);
    }

    public function warehouse()
    {
        return $this->belongsTo(WarehousesList::class, 'warehouse_id');
    }

    public function getDateAttribute($value)
    {
        return $value ? Carbon::parse($value)->format(config('panel.date_format')) : null;
    }

    public function setDateAttribute($value)
    {
        $this->attributes['date'] = $value ? Carbon::createFromFormat(config('panel.date_format'), $value)->format('Y-m-d') : null;
    }

    public function team()
    {
        return $this->belongsTo(Team::class, 'team_id');
    }

    protected function serializeDate(DateTimeInterface $date)
    {
        return $date->format('Y-m-d H:i:s');
    }
}
