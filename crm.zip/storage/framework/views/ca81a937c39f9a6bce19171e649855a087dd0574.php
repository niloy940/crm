<aside class="main-sidebar sidebar-dark-primary elevation-4" style="min-height: 917px;">
    <!-- Brand Logo -->
    <a href="#" class="brand-link">
        <span class="brand-text font-weight-light"><?php echo e(trans('panel.site_title')); ?></span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
        <!-- Sidebar user (optional) -->

        <!-- Sidebar Menu -->
        <nav class="mt-2">
            <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
                <li>
                    <select class="searchable-field form-control">

                    </select>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route("admin.home")); ?>">
                        <i class="fas fa-fw fa-tachometer-alt nav-icon">
                        </i>
                        <p>
                            <?php echo e(trans('global.dashboard')); ?>

                        </p>
                    </a>
                </li>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user_management_access')): ?>
                    <li class="nav-item has-treeview <?php echo e(request()->is("admin/users*") ? "menu-open" : ""); ?> <?php echo e(request()->is("admin/roles*") ? "menu-open" : ""); ?> <?php echo e(request()->is("admin/permissions*") ? "menu-open" : ""); ?> <?php echo e(request()->is("admin/teams*") ? "menu-open" : ""); ?> <?php echo e(request()->is("admin/audit-logs*") ? "menu-open" : ""); ?>">
                        <a class="nav-link nav-dropdown-toggle" href="#">
                            <i class="fa-fw nav-icon fas fa-users">

                            </i>
                            <p>
                                <?php echo e(trans('cruds.userManagement.title')); ?>

                                <i class="right fa fa-fw fa-angle-left nav-icon"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user_access')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route("admin.users.index")); ?>" class="nav-link <?php echo e(request()->is("admin/users") || request()->is("admin/users/*") ? "active" : ""); ?>">
                                        <i class="fa-fw nav-icon fas fa-user">

                                        </i>
                                        <p>
                                            <?php echo e(trans('cruds.user.title')); ?>

                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role_access')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route("admin.roles.index")); ?>" class="nav-link <?php echo e(request()->is("admin/roles") || request()->is("admin/roles/*") ? "active" : ""); ?>">
                                        <i class="fa-fw nav-icon fas fa-briefcase">

                                        </i>
                                        <p>
                                            <?php echo e(trans('cruds.role.title')); ?>

                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('permission_access')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route("admin.permissions.index")); ?>" class="nav-link <?php echo e(request()->is("admin/permissions") || request()->is("admin/permissions/*") ? "active" : ""); ?>">
                                        <i class="fa-fw nav-icon fas fa-unlock-alt">

                                        </i>
                                        <p>
                                            <?php echo e(trans('cruds.permission.title')); ?>

                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('team_access')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route("admin.teams.index")); ?>" class="nav-link <?php echo e(request()->is("admin/teams") || request()->is("admin/teams/*") ? "active" : ""); ?>">
                                        <i class="fa-fw nav-icon fas fa-users">

                                        </i>
                                        <p>
                                            <?php echo e(trans('cruds.team.title')); ?>

                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('audit_log_access')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route("admin.audit-logs.index")); ?>" class="nav-link <?php echo e(request()->is("admin/audit-logs") || request()->is("admin/audit-logs/*") ? "active" : ""); ?>">
                                        <i class="fa-fw nav-icon fas fa-file-alt">

                                        </i>
                                        <p>
                                            <?php echo e(trans('cruds.auditLog.title')); ?>

                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('product_access')): ?>
                    <li class="nav-item has-treeview <?php echo e(request()->is("admin/products-lists*") ? "menu-open" : ""); ?>">
                        <a class="nav-link nav-dropdown-toggle" href="#">
                            <i class="fa-fw nav-icon fas fa-cogs">

                            </i>
                            <p>
                                <?php echo e(trans('cruds.product.title')); ?>

                                <i class="right fa fa-fw fa-angle-left nav-icon"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('products_list_access')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route("admin.products-lists.index")); ?>" class="nav-link <?php echo e(request()->is("admin/products-lists") || request()->is("admin/products-lists/*") ? "active" : ""); ?>">
                                        <i class="fa-fw nav-icon fas fa-cogs">

                                        </i>
                                        <p>
                                            <?php echo e(trans('cruds.productsList.title')); ?>

                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('warehouse_access')): ?>
                    <li class="nav-item has-treeview <?php echo e(request()->is("admin/warehouses-lists*") ? "menu-open" : ""); ?> <?php echo e(request()->is("admin/receipt-notes*") ? "menu-open" : ""); ?> <?php echo e(request()->is("admin/identification-cards*") ? "menu-open" : ""); ?> <?php echo e(request()->is("admin/delivery-notes*") ? "menu-open" : ""); ?> <?php echo e(request()->is("admin/warehouse-transfers*") ? "menu-open" : ""); ?> <?php echo e(request()->is("admin/packing-lists*") ? "menu-open" : ""); ?>">
                        <a class="nav-link nav-dropdown-toggle" href="#">
                            <i class="fa-fw nav-icon fas fa-warehouse">

                            </i>
                            <p>
                                <?php echo e(trans('cruds.warehouse.title')); ?>

                                <i class="right fa fa-fw fa-angle-left nav-icon"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('warehouses_list_access')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route("admin.warehouses-lists.index")); ?>" class="nav-link <?php echo e(request()->is("admin/warehouses-lists") || request()->is("admin/warehouses-lists/*") ? "active" : ""); ?>">
                                        <i class="fa-fw nav-icon fas fa-warehouse">

                                        </i>
                                        <p>
                                            <?php echo e(trans('cruds.warehousesList.title')); ?>

                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('receipt_note_access')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route("admin.receipt-notes.index")); ?>" class="nav-link <?php echo e(request()->is("admin/receipt-notes") || request()->is("admin/receipt-notes/*") ? "active" : ""); ?>">
                                        <i class="fa-fw nav-icon fas fa-arrow-left">

                                        </i>
                                        <p>
                                            <?php echo e(trans('cruds.receiptNote.title')); ?>

                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('identification_card_access')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route("admin.identification-cards.index")); ?>" class="nav-link <?php echo e(request()->is("admin/identification-cards") || request()->is("admin/identification-cards/*") ? "active" : ""); ?>">
                                        <i class="fa-fw nav-icon fas fa-clipboard-list">

                                        </i>
                                        <p>
                                            <?php echo e(trans('cruds.identificationCard.title')); ?>

                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delivery_note_access')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route("admin.delivery-notes.index")); ?>" class="nav-link <?php echo e(request()->is("admin/delivery-notes") || request()->is("admin/delivery-notes/*") ? "active" : ""); ?>">
                                        <i class="fa-fw nav-icon fas fa-arrow-right">

                                        </i>
                                        <p>
                                            <?php echo e(trans('cruds.deliveryNote.title')); ?>

                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('warehouse_transfer_access')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route("admin.warehouse-transfers.index")); ?>" class="nav-link <?php echo e(request()->is("admin/warehouse-transfers") || request()->is("admin/warehouse-transfers/*") ? "active" : ""); ?>">
                                        <i class="fa-fw nav-icon fas fa-arrows-alt-h">

                                        </i>
                                        <p>
                                            <?php echo e(trans('cruds.warehouseTransfer.title')); ?>

                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('packing_list_access')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route("admin.packing-lists.index")); ?>" class="nav-link <?php echo e(request()->is("admin/packing-lists") || request()->is("admin/packing-lists/*") ? "active" : ""); ?>">
                                        <i class="fa-fw nav-icon fas fa-cube">

                                        </i>
                                        <p>
                                            <?php echo e(trans('cruds.packingList.title')); ?>

                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('basic_c_r_m_access')): ?>
                    <li class="nav-item has-treeview <?php echo e(request()->is("admin/crm-customers*") ? "menu-open" : ""); ?> <?php echo e(request()->is("admin/crm-statuses*") ? "menu-open" : ""); ?> <?php echo e(request()->is("admin/crm-notes*") ? "menu-open" : ""); ?> <?php echo e(request()->is("admin/crm-documents*") ? "menu-open" : ""); ?>">
                        <a class="nav-link nav-dropdown-toggle" href="#">
                            <i class="fa-fw nav-icon fas fa-briefcase">

                            </i>
                            <p>
                                <?php echo e(trans('cruds.basicCRM.title')); ?>

                                <i class="right fa fa-fw fa-angle-left nav-icon"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('crm_customer_access')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route("admin.crm-customers.index")); ?>" class="nav-link <?php echo e(request()->is("admin/crm-customers") || request()->is("admin/crm-customers/*") ? "active" : ""); ?>">
                                        <i class="fa-fw nav-icon fas fa-user-plus">

                                        </i>
                                        <p>
                                            <?php echo e(trans('cruds.crmCustomer.title')); ?>

                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('crm_status_access')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route("admin.crm-statuses.index")); ?>" class="nav-link <?php echo e(request()->is("admin/crm-statuses") || request()->is("admin/crm-statuses/*") ? "active" : ""); ?>">
                                        <i class="fa-fw nav-icon fas fa-folder">

                                        </i>
                                        <p>
                                            <?php echo e(trans('cruds.crmStatus.title')); ?>

                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('crm_note_access')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route("admin.crm-notes.index")); ?>" class="nav-link <?php echo e(request()->is("admin/crm-notes") || request()->is("admin/crm-notes/*") ? "active" : ""); ?>">
                                        <i class="fa-fw nav-icon fas fa-sticky-note">

                                        </i>
                                        <p>
                                            <?php echo e(trans('cruds.crmNote.title')); ?>

                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('crm_document_access')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route("admin.crm-documents.index")); ?>" class="nav-link <?php echo e(request()->is("admin/crm-documents") || request()->is("admin/crm-documents/*") ? "active" : ""); ?>">
                                        <i class="fa-fw nav-icon fas fa-folder">

                                        </i>
                                        <p>
                                            <?php echo e(trans('cruds.crmDocument.title')); ?>

                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('task_management_access')): ?>
                    <li class="nav-item has-treeview <?php echo e(request()->is("admin/user-alerts*") ? "menu-open" : ""); ?> <?php echo e(request()->is("admin/task-statuses*") ? "menu-open" : ""); ?> <?php echo e(request()->is("admin/task-tags*") ? "menu-open" : ""); ?> <?php echo e(request()->is("admin/tasks*") ? "menu-open" : ""); ?> <?php echo e(request()->is("admin/tasks-calendars*") ? "menu-open" : ""); ?>">
                        <a class="nav-link nav-dropdown-toggle" href="#">
                            <i class="fa-fw nav-icon fas fa-tasks">

                            </i>
                            <p>
                                <?php echo e(trans('cruds.taskManagement.title')); ?>

                                <i class="right fa fa-fw fa-angle-left nav-icon"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user_alert_access')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route("admin.user-alerts.index")); ?>" class="nav-link <?php echo e(request()->is("admin/user-alerts") || request()->is("admin/user-alerts/*") ? "active" : ""); ?>">
                                        <i class="fa-fw nav-icon fas fa-bell">

                                        </i>
                                        <p>
                                            <?php echo e(trans('cruds.userAlert.title')); ?>

                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('task_status_access')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route("admin.task-statuses.index")); ?>" class="nav-link <?php echo e(request()->is("admin/task-statuses") || request()->is("admin/task-statuses/*") ? "active" : ""); ?>">
                                        <i class="fa-fw nav-icon fas fa-server">

                                        </i>
                                        <p>
                                            <?php echo e(trans('cruds.taskStatus.title')); ?>

                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('task_tag_access')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route("admin.task-tags.index")); ?>" class="nav-link <?php echo e(request()->is("admin/task-tags") || request()->is("admin/task-tags/*") ? "active" : ""); ?>">
                                        <i class="fa-fw nav-icon fas fa-server">

                                        </i>
                                        <p>
                                            <?php echo e(trans('cruds.taskTag.title')); ?>

                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('task_access')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route("admin.tasks.index")); ?>" class="nav-link <?php echo e(request()->is("admin/tasks") || request()->is("admin/tasks/*") ? "active" : ""); ?>">
                                        <i class="fa-fw nav-icon fas fa-briefcase">

                                        </i>
                                        <p>
                                            <?php echo e(trans('cruds.task.title')); ?>

                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('tasks_calendar_access')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route("admin.tasks-calendars.index")); ?>" class="nav-link <?php echo e(request()->is("admin/tasks-calendars") || request()->is("admin/tasks-calendars/*") ? "active" : ""); ?>">
                                        <i class="fa-fw nav-icon fas fa-calendar">

                                        </i>
                                        <p>
                                            <?php echo e(trans('cruds.tasksCalendar.title')); ?>

                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('asset_management_access')): ?>
                    <li class="nav-item has-treeview <?php echo e(request()->is("admin/asset-locations*") ? "menu-open" : ""); ?> <?php echo e(request()->is("admin/asset-categories*") ? "menu-open" : ""); ?> <?php echo e(request()->is("admin/asset-statuses*") ? "menu-open" : ""); ?> <?php echo e(request()->is("admin/assets*") ? "menu-open" : ""); ?> <?php echo e(request()->is("admin/assets-histories*") ? "menu-open" : ""); ?>">
                        <a class="nav-link nav-dropdown-toggle" href="#">
                            <i class="fa-fw nav-icon fas fa-book">

                            </i>
                            <p>
                                <?php echo e(trans('cruds.assetManagement.title')); ?>

                                <i class="right fa fa-fw fa-angle-left nav-icon"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('asset_location_access')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route("admin.asset-locations.index")); ?>" class="nav-link <?php echo e(request()->is("admin/asset-locations") || request()->is("admin/asset-locations/*") ? "active" : ""); ?>">
                                        <i class="fa-fw nav-icon fas fa-map-marker">

                                        </i>
                                        <p>
                                            <?php echo e(trans('cruds.assetLocation.title')); ?>

                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('asset_category_access')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route("admin.asset-categories.index")); ?>" class="nav-link <?php echo e(request()->is("admin/asset-categories") || request()->is("admin/asset-categories/*") ? "active" : ""); ?>">
                                        <i class="fa-fw nav-icon fas fa-tags">

                                        </i>
                                        <p>
                                            <?php echo e(trans('cruds.assetCategory.title')); ?>

                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('asset_status_access')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route("admin.asset-statuses.index")); ?>" class="nav-link <?php echo e(request()->is("admin/asset-statuses") || request()->is("admin/asset-statuses/*") ? "active" : ""); ?>">
                                        <i class="fa-fw nav-icon fas fa-server">

                                        </i>
                                        <p>
                                            <?php echo e(trans('cruds.assetStatus.title')); ?>

                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('asset_access')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route("admin.assets.index")); ?>" class="nav-link <?php echo e(request()->is("admin/assets") || request()->is("admin/assets/*") ? "active" : ""); ?>">
                                        <i class="fa-fw nav-icon fas fa-book">

                                        </i>
                                        <p>
                                            <?php echo e(trans('cruds.asset.title')); ?>

                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('assets_history_access')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route("admin.assets-histories.index")); ?>" class="nav-link <?php echo e(request()->is("admin/assets-histories") || request()->is("admin/assets-histories/*") ? "active" : ""); ?>">
                                        <i class="fa-fw nav-icon fas fa-th-list">

                                        </i>
                                        <p>
                                            <?php echo e(trans('cruds.assetsHistory.title')); ?>

                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('time_management_access')): ?>
                    <li class="nav-item has-treeview <?php echo e(request()->is("admin/time-work-types*") ? "menu-open" : ""); ?> <?php echo e(request()->is("admin/time-projects*") ? "menu-open" : ""); ?> <?php echo e(request()->is("admin/time-entries*") ? "menu-open" : ""); ?> <?php echo e(request()->is("admin/time-reports*") ? "menu-open" : ""); ?>">
                        <a class="nav-link nav-dropdown-toggle" href="#">
                            <i class="fa-fw nav-icon fas fa-clock">

                            </i>
                            <p>
                                <?php echo e(trans('cruds.timeManagement.title')); ?>

                                <i class="right fa fa-fw fa-angle-left nav-icon"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('time_work_type_access')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route("admin.time-work-types.index")); ?>" class="nav-link <?php echo e(request()->is("admin/time-work-types") || request()->is("admin/time-work-types/*") ? "active" : ""); ?>">
                                        <i class="fa-fw nav-icon fas fa-th">

                                        </i>
                                        <p>
                                            <?php echo e(trans('cruds.timeWorkType.title')); ?>

                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('time_project_access')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route("admin.time-projects.index")); ?>" class="nav-link <?php echo e(request()->is("admin/time-projects") || request()->is("admin/time-projects/*") ? "active" : ""); ?>">
                                        <i class="fa-fw nav-icon fas fa-briefcase">

                                        </i>
                                        <p>
                                            <?php echo e(trans('cruds.timeProject.title')); ?>

                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('time_entry_access')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route("admin.time-entries.index")); ?>" class="nav-link <?php echo e(request()->is("admin/time-entries") || request()->is("admin/time-entries/*") ? "active" : ""); ?>">
                                        <i class="fa-fw nav-icon fas fa-briefcase">

                                        </i>
                                        <p>
                                            <?php echo e(trans('cruds.timeEntry.title')); ?>

                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('time_report_access')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route("admin.time-reports.index")); ?>" class="nav-link <?php echo e(request()->is("admin/time-reports") || request()->is("admin/time-reports/*") ? "active" : ""); ?>">
                                        <i class="fa-fw nav-icon fas fa-chart-line">

                                        </i>
                                        <p>
                                            <?php echo e(trans('cruds.timeReport.title')); ?>

                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('faq_management_access')): ?>
                    <li class="nav-item has-treeview <?php echo e(request()->is("admin/faq-categories*") ? "menu-open" : ""); ?> <?php echo e(request()->is("admin/faq-questions*") ? "menu-open" : ""); ?>">
                        <a class="nav-link nav-dropdown-toggle" href="#">
                            <i class="fa-fw nav-icon fas fa-question">

                            </i>
                            <p>
                                <?php echo e(trans('cruds.faqManagement.title')); ?>

                                <i class="right fa fa-fw fa-angle-left nav-icon"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('faq_category_access')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route("admin.faq-categories.index")); ?>" class="nav-link <?php echo e(request()->is("admin/faq-categories") || request()->is("admin/faq-categories/*") ? "active" : ""); ?>">
                                        <i class="fa-fw nav-icon fas fa-briefcase">

                                        </i>
                                        <p>
                                            <?php echo e(trans('cruds.faqCategory.title')); ?>

                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('faq_question_access')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route("admin.faq-questions.index")); ?>" class="nav-link <?php echo e(request()->is("admin/faq-questions") || request()->is("admin/faq-questions/*") ? "active" : ""); ?>">
                                        <i class="fa-fw nav-icon fas fa-question">

                                        </i>
                                        <p>
                                            <?php echo e(trans('cruds.faqQuestion.title')); ?>

                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </li>
                <?php endif; ?>
                <?php ($unread = \App\Models\QaTopic::unreadCount()); ?>
                    <li class="nav-item">
                        <a href="<?php echo e(route("admin.messenger.index")); ?>" class="<?php echo e(request()->is("admin/messenger") || request()->is("admin/messenger/*") ? "active" : ""); ?> nav-link">
                            <i class="fa-fw fa fa-envelope nav-icon">

                            </i>
                            <p><?php echo e(trans('global.messages')); ?></p>
                            <?php if($unread > 0): ?>
                                <strong>( <?php echo e($unread); ?> )</strong>
                            <?php endif; ?>

                        </a>
                    </li>
                    <?php if(\Illuminate\Support\Facades\Schema::hasColumn('teams', 'owner_id') && \App\Models\Team::where('owner_id', auth()->user()->id)->exists()): ?>
                        <li class="nav-item">
                            <a class="<?php echo e(request()->is("admin/team-members") || request()->is("admin/team-members/*") ? "active" : ""); ?> nav-link" href="<?php echo e(route("admin.team-members.index")); ?>">
                                <i class="fa-fw fa fa-users nav-icon">
                                </i>
                                <p>
                                    <?php echo e(trans("global.team-members")); ?>

                                </p>
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if(file_exists(app_path('Http/Controllers/Auth/ChangePasswordController.php'))): ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('profile_password_edit')): ?>
                            <li class="nav-item">
                                <a class="nav-link <?php echo e(request()->is('profile/password') || request()->is('profile/password/*') ? 'active' : ''); ?>" href="<?php echo e(route('profile.password.edit')); ?>">
                                    <i class="fa-fw fas fa-key nav-icon">
                                    </i>
                                    <p>
                                        <?php echo e(trans('global.change_password')); ?>

                                    </p>
                                </a>
                            </li>
                        <?php endif; ?>
                    <?php endif; ?>
                    <li class="nav-item">
                        <a href="#" class="nav-link" onclick="event.preventDefault(); document.getElementById('logoutform').submit();">
                            <p>
                                <i class="fas fa-fw fa-sign-out-alt nav-icon">

                                </i>
                                <p><?php echo e(trans('global.logout')); ?></p>
                            </p>
                        </a>
                    </li>
            </ul>
        </nav>
        <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
</aside><?php /**PATH C:\xampp\htdocs\crm\resources\views/partials/menu.blade.php ENDPATH**/ ?>