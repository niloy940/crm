@extends('layouts.admin')
@section('content')

<div class="card">
    <div class="card-header">
        {{ trans('global.edit') }} {{ trans('cruds.identificationCard.title_singular') }}
    </div>

    <div class="card-body">
        <form method="POST" action="{{ route("admin.identification-cards.update", [$identificationCard->id]) }}" enctype="multipart/form-data">
            @method('PUT')
            @csrf
            <div class="form-group">
                <label class="required" for="product_id">{{ trans('cruds.identificationCard.fields.product') }}</label>
                <select class="form-control select2 {{ $errors->has('product') ? 'is-invalid' : '' }}" name="product_id" id="product_id" required>
                    @foreach($products as $id => $entry)
                        <option value="{{ $id }}" {{ (old('product_id') ? old('product_id') : $identificationCard->product->id ?? '') == $id ? 'selected' : '' }}>{{ $entry }}</option>
                    @endforeach
                </select>
                @if($errors->has('product'))
                    <span class="text-danger">{{ $errors->first('product') }}</span>
                @endif
                <span class="help-block">{{ trans('cruds.identificationCard.fields.product_helper') }}</span>
            </div>
            <div class="form-group">
                <label class="required" for="quantity">{{ trans('cruds.identificationCard.fields.quantity') }}</label>
                <input class="form-control {{ $errors->has('quantity') ? 'is-invalid' : '' }}" type="number" name="quantity" id="quantity" value="{{ old('quantity', $identificationCard->quantity) }}" step="0.001" required>
                @if($errors->has('quantity'))
                    <span class="text-danger">{{ $errors->first('quantity') }}</span>
                @endif
                <span class="help-block">{{ trans('cruds.identificationCard.fields.quantity_helper') }}</span>
            </div>
            <div class="form-group">
                <label class="required" for="lot_id">{{ trans('cruds.identificationCard.fields.lot') }}</label>
                <select class="form-control select2 {{ $errors->has('lot') ? 'is-invalid' : '' }}" name="lot_id" id="lot_id" required>
                    @foreach($lots as $id => $entry)
                        <option value="{{ $id }}" {{ (old('lot_id') ? old('lot_id') : $identificationCard->lot->id ?? '') == $id ? 'selected' : '' }}>{{ $entry }}</option>
                    @endforeach
                </select>
                @if($errors->has('lot'))
                    <span class="text-danger">{{ $errors->first('lot') }}</span>
                @endif
                <span class="help-block">{{ trans('cruds.identificationCard.fields.lot_helper') }}</span>
            </div>
            <div class="form-group">
                <label class="required" for="int_lot">{{ trans('cruds.identificationCard.fields.int_lot') }}</label>
                <input class="form-control {{ $errors->has('int_lot') ? 'is-invalid' : '' }}" type="text" name="int_lot" id="int_lot" value="{{ old('int_lot', $identificationCard->int_lot) }}" required>
                @if($errors->has('int_lot'))
                    <span class="text-danger">{{ $errors->first('int_lot') }}</span>
                @endif
                <span class="help-block">{{ trans('cruds.identificationCard.fields.int_lot_helper') }}</span>
            </div>
            <div class="form-group">
                <label class="required" for="storage_cond">{{ trans('cruds.identificationCard.fields.storage_cond') }}</label>
                <input class="form-control {{ $errors->has('storage_cond') ? 'is-invalid' : '' }}" type="text" name="storage_cond" id="storage_cond" value="{{ old('storage_cond', $identificationCard->storage_cond) }}" required>
                @if($errors->has('storage_cond'))
                    <span class="text-danger">{{ $errors->first('storage_cond') }}</span>
                @endif
                <span class="help-block">{{ trans('cruds.identificationCard.fields.storage_cond_helper') }}</span>
            </div>
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    {{ trans('global.save') }}
                </button>
            </div>
        </form>
    </div>
</div>



@endsection