
<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.create')); ?> <?php echo e(trans('cruds.receiptNote.title_singular')); ?>

    </div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route("admin.receipt-notes.store")); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label class="required" for="client_id"><?php echo e(trans('cruds.receiptNote.fields.client')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('client') ? 'is-invalid' : ''); ?>" name="client_id" id="client_id" required>
                    <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e(old('client_id') == $id ? 'selected' : ''); ?>><?php echo e($entry); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('client')): ?>
                    <span class="text-danger"><?php echo e($errors->first('client')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.receiptNote.fields.client_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="products"><?php echo e(trans('cruds.receiptNote.fields.product')); ?></label>
                <div style="padding-bottom: 4px">
                    <span class="btn btn-info btn-xs select-all" style="border-radius: 0"><?php echo e(trans('global.select_all')); ?></span>
                    <span class="btn btn-info btn-xs deselect-all" style="border-radius: 0"><?php echo e(trans('global.deselect_all')); ?></span>
                </div>
                <select class="form-control select2 <?php echo e($errors->has('products') ? 'is-invalid' : ''); ?>" name="products[]" id="products" multiple required>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e(in_array($id, old('products', [])) ? 'selected' : ''); ?>><?php echo e($product); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('products')): ?>
                    <span class="text-danger"><?php echo e($errors->first('products')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.receiptNote.fields.product_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="quantity"><?php echo e(trans('cruds.receiptNote.fields.quantity')); ?></label>
                <input class="form-control <?php echo e($errors->has('quantity') ? 'is-invalid' : ''); ?>" type="number" name="quantity" id="quantity" value="<?php echo e(old('quantity', '')); ?>" step="0.001" required>
                <?php if($errors->has('quantity')): ?>
                    <span class="text-danger"><?php echo e($errors->first('quantity')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.receiptNote.fields.quantity_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="lot"><?php echo e(trans('cruds.receiptNote.fields.lot')); ?></label>
                <input class="form-control <?php echo e($errors->has('lot') ? 'is-invalid' : ''); ?>" type="text" name="lot" id="lot" value="<?php echo e(old('lot', '')); ?>" required>
                <?php if($errors->has('lot')): ?>
                    <span class="text-danger"><?php echo e($errors->first('lot')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.receiptNote.fields.lot_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="int_lot"><?php echo e(trans('cruds.receiptNote.fields.int_lot')); ?></label>
                <input class="form-control <?php echo e($errors->has('int_lot') ? 'is-invalid' : ''); ?>" type="text" name="int_lot" id="int_lot" value="<?php echo e(old('int_lot', '')); ?>" required>
                <?php if($errors->has('int_lot')): ?>
                    <span class="text-danger"><?php echo e($errors->first('int_lot')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.receiptNote.fields.int_lot_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="warehouse_id"><?php echo e(trans('cruds.receiptNote.fields.warehouse')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('warehouse') ? 'is-invalid' : ''); ?>" name="warehouse_id" id="warehouse_id" required>
                    <?php $__currentLoopData = $warehouses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e(old('warehouse_id') == $id ? 'selected' : ''); ?>><?php echo e($entry); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('warehouse')): ?>
                    <span class="text-danger"><?php echo e($errors->first('warehouse')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.receiptNote.fields.warehouse_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required"><?php echo e(trans('cruds.receiptNote.fields.qc')); ?></label>
                <select class="form-control <?php echo e($errors->has('qc') ? 'is-invalid' : ''); ?>" name="qc" id="qc" required>
                    <option value disabled <?php echo e(old('qc', null) === null ? 'selected' : ''); ?>><?php echo e(trans('global.pleaseSelect')); ?></option>
                    <?php $__currentLoopData = App\Models\ReceiptNote::QC_SELECT; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>" <?php echo e(old('qc', '') === (string) $key ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('qc')): ?>
                    <span class="text-danger"><?php echo e($errors->first('qc')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.receiptNote.fields.qc_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required"><?php echo e(trans('cruds.receiptNote.fields.shift')); ?></label>
                <select class="form-control <?php echo e($errors->has('shift') ? 'is-invalid' : ''); ?>" name="shift" id="shift" required>
                    <option value disabled <?php echo e(old('shift', null) === null ? 'selected' : ''); ?>><?php echo e(trans('global.pleaseSelect')); ?></option>
                    <?php $__currentLoopData = App\Models\ReceiptNote::SHIFT_SELECT; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>" <?php echo e(old('shift', '') === (string) $key ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('shift')): ?>
                    <span class="text-danger"><?php echo e($errors->first('shift')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.receiptNote.fields.shift_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="date"><?php echo e(trans('cruds.receiptNote.fields.date')); ?></label>
                <input class="form-control date <?php echo e($errors->has('date') ? 'is-invalid' : ''); ?>" type="text" name="date" id="date" value="<?php echo e(old('date')); ?>" required>
                <?php if($errors->has('date')): ?>
                    <span class="text-danger"><?php echo e($errors->first('date')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.receiptNote.fields.date_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="place"><?php echo e(trans('cruds.receiptNote.fields.place')); ?></label>
                <input class="form-control <?php echo e($errors->has('place') ? 'is-invalid' : ''); ?>" type="text" name="place" id="place" value="<?php echo e(old('place', 'Banatski Karlovac')); ?>" required>
                <?php if($errors->has('place')): ?>
                    <span class="text-danger"><?php echo e($errors->first('place')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.receiptNote.fields.place_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="driver"><?php echo e(trans('cruds.receiptNote.fields.driver')); ?></label>
                <input class="form-control <?php echo e($errors->has('driver') ? 'is-invalid' : ''); ?>" type="text" name="driver" id="driver" value="<?php echo e(old('driver', '')); ?>" required>
                <?php if($errors->has('driver')): ?>
                    <span class="text-danger"><?php echo e($errors->first('driver')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.receiptNote.fields.driver_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="id_driver"><?php echo e(trans('cruds.receiptNote.fields.id_driver')); ?></label>
                <input class="form-control <?php echo e($errors->has('id_driver') ? 'is-invalid' : ''); ?>" type="text" name="id_driver" id="id_driver" value="<?php echo e(old('id_driver', '')); ?>" required>
                <?php if($errors->has('id_driver')): ?>
                    <span class="text-danger"><?php echo e($errors->first('id_driver')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.receiptNote.fields.id_driver_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="registration"><?php echo e(trans('cruds.receiptNote.fields.registration')); ?></label>
                <input class="form-control <?php echo e($errors->has('registration') ? 'is-invalid' : ''); ?>" type="text" name="registration" id="registration" value="<?php echo e(old('registration', '')); ?>" required>
                <?php if($errors->has('registration')): ?>
                    <span class="text-danger"><?php echo e($errors->first('registration')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.receiptNote.fields.registration_helper')); ?></span>
            </div>
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    <?php echo e(trans('global.save')); ?>

                </button>
            </div>
        </form>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\crm\resources\views/admin/receiptNotes/create.blade.php ENDPATH**/ ?>