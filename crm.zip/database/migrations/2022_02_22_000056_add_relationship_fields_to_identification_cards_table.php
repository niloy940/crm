<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddRelationshipFieldsToIdentificationCardsTable extends Migration
{
    public function up()
    {
        Schema::table('identification_cards', function (Blueprint $table) {
            $table->unsignedBigInteger('product_id')->nullable();
            $table->foreign('product_id', 'product_fk_6050911')->references('id')->on('products_lists');
            $table->unsignedBigInteger('lot_id')->nullable();
            $table->foreign('lot_id', 'lot_fk_6050913')->references('id')->on('receipt_notes');
            $table->unsignedBigInteger('team_id')->nullable();
            $table->foreign('team_id', 'team_fk_6050919')->references('id')->on('teams');
        });
    }
}
