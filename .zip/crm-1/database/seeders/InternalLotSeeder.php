<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class InternalLotSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
    }
}
