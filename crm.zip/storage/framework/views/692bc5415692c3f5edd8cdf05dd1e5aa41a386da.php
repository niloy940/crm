
<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.create')); ?> <?php echo e(trans('cruds.packingList.title_singular')); ?>

    </div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route("admin.packing-lists.store")); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label class="required" for="client_id"><?php echo e(trans('cruds.packingList.fields.client')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('client') ? 'is-invalid' : ''); ?>" name="client_id" id="client_id" required>
                    <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e(old('client_id') == $id ? 'selected' : ''); ?>><?php echo e($entry); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('client')): ?>
                    <span class="text-danger"><?php echo e($errors->first('client')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.packingList.fields.client_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="product_id"><?php echo e(trans('cruds.packingList.fields.product')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('product') ? 'is-invalid' : ''); ?>" name="product_id" id="product_id">
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e(old('product_id') == $id ? 'selected' : ''); ?>><?php echo e($entry); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('product')): ?>
                    <span class="text-danger"><?php echo e($errors->first('product')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.packingList.fields.product_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="quantity"><?php echo e(trans('cruds.packingList.fields.quantity')); ?></label>
                <input class="form-control <?php echo e($errors->has('quantity') ? 'is-invalid' : ''); ?>" type="number" name="quantity" id="quantity" value="<?php echo e(old('quantity', '')); ?>" step="0.001" required>
                <?php if($errors->has('quantity')): ?>
                    <span class="text-danger"><?php echo e($errors->first('quantity')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.packingList.fields.quantity_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="lots"><?php echo e(trans('cruds.packingList.fields.lot')); ?></label>
                <div style="padding-bottom: 4px">
                    <span class="btn btn-info btn-xs select-all" style="border-radius: 0"><?php echo e(trans('global.select_all')); ?></span>
                    <span class="btn btn-info btn-xs deselect-all" style="border-radius: 0"><?php echo e(trans('global.deselect_all')); ?></span>
                </div>
                <select class="form-control select2 <?php echo e($errors->has('lots') ? 'is-invalid' : ''); ?>" name="lots[]" id="lots" multiple>
                    <?php $__currentLoopData = $lots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $lot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e(in_array($id, old('lots', [])) ? 'selected' : ''); ?>><?php echo e($lot); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('lots')): ?>
                    <span class="text-danger"><?php echo e($errors->first('lots')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.packingList.fields.lot_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="net_weight"><?php echo e(trans('cruds.packingList.fields.net_weight')); ?></label>
                <input class="form-control <?php echo e($errors->has('net_weight') ? 'is-invalid' : ''); ?>" type="number" name="net_weight" id="net_weight" value="<?php echo e(old('net_weight', '')); ?>" step="0.001" required>
                <?php if($errors->has('net_weight')): ?>
                    <span class="text-danger"><?php echo e($errors->first('net_weight')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.packingList.fields.net_weight_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="bruto_weight"><?php echo e(trans('cruds.packingList.fields.bruto_weight')); ?></label>
                <input class="form-control <?php echo e($errors->has('bruto_weight') ? 'is-invalid' : ''); ?>" type="number" name="bruto_weight" id="bruto_weight" value="<?php echo e(old('bruto_weight', '')); ?>" step="0.001" required>
                <?php if($errors->has('bruto_weight')): ?>
                    <span class="text-danger"><?php echo e($errors->first('bruto_weight')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.packingList.fields.bruto_weight_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="width"><?php echo e(trans('cruds.packingList.fields.width')); ?></label>
                <input class="form-control <?php echo e($errors->has('width') ? 'is-invalid' : ''); ?>" type="number" name="width" id="width" value="<?php echo e(old('width', '')); ?>" step="1" required>
                <?php if($errors->has('width')): ?>
                    <span class="text-danger"><?php echo e($errors->first('width')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.packingList.fields.width_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="height"><?php echo e(trans('cruds.packingList.fields.height')); ?></label>
                <input class="form-control <?php echo e($errors->has('height') ? 'is-invalid' : ''); ?>" type="number" name="height" id="height" value="<?php echo e(old('height', '')); ?>" step="1" required>
                <?php if($errors->has('height')): ?>
                    <span class="text-danger"><?php echo e($errors->first('height')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.packingList.fields.height_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="length"><?php echo e(trans('cruds.packingList.fields.length')); ?></label>
                <input class="form-control <?php echo e($errors->has('length') ? 'is-invalid' : ''); ?>" type="number" name="length" id="length" value="<?php echo e(old('length', '')); ?>" step="1" required>
                <?php if($errors->has('length')): ?>
                    <span class="text-danger"><?php echo e($errors->first('length')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.packingList.fields.length_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="user_id"><?php echo e(trans('cruds.packingList.fields.user')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('user') ? 'is-invalid' : ''); ?>" name="user_id" id="user_id" required>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e(old('user_id') == $id ? 'selected' : ''); ?>><?php echo e($entry); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('user')): ?>
                    <span class="text-danger"><?php echo e($errors->first('user')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.packingList.fields.user_helper')); ?></span>
            </div>
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    <?php echo e(trans('global.save')); ?>

                </button>
            </div>
        </form>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\crm\resources\views/admin/packingLists/create.blade.php ENDPATH**/ ?>