
<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.create')); ?> <?php echo e(trans('cruds.task.title_singular')); ?>

    </div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route("admin.tasks.store")); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label class="required" for="name"><?php echo e(trans('cruds.task.fields.name')); ?></label>
                <input class="form-control <?php echo e($errors->has('name') ? 'is-invalid' : ''); ?>" type="text" name="name" id="name" value="<?php echo e(old('name', '')); ?>" required>
                <?php if($errors->has('name')): ?>
                    <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.task.fields.name_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="description"><?php echo e(trans('cruds.task.fields.description')); ?></label>
                <textarea class="form-control <?php echo e($errors->has('description') ? 'is-invalid' : ''); ?>" name="description" id="description"><?php echo e(old('description')); ?></textarea>
                <?php if($errors->has('description')): ?>
                    <span class="text-danger"><?php echo e($errors->first('description')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.task.fields.description_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="status_id"><?php echo e(trans('cruds.task.fields.status')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('status') ? 'is-invalid' : ''); ?>" name="status_id" id="status_id" required>
                    <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e(old('status_id') == $id ? 'selected' : ''); ?>><?php echo e($entry); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('status')): ?>
                    <span class="text-danger"><?php echo e($errors->first('status')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.task.fields.status_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="tags"><?php echo e(trans('cruds.task.fields.tag')); ?></label>
                <div style="padding-bottom: 4px">
                    <span class="btn btn-info btn-xs select-all" style="border-radius: 0"><?php echo e(trans('global.select_all')); ?></span>
                    <span class="btn btn-info btn-xs deselect-all" style="border-radius: 0"><?php echo e(trans('global.deselect_all')); ?></span>
                </div>
                <select class="form-control select2 <?php echo e($errors->has('tags') ? 'is-invalid' : ''); ?>" name="tags[]" id="tags" multiple>
                    <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e(in_array($id, old('tags', [])) ? 'selected' : ''); ?>><?php echo e($tag); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('tags')): ?>
                    <span class="text-danger"><?php echo e($errors->first('tags')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.task.fields.tag_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="attachment"><?php echo e(trans('cruds.task.fields.attachment')); ?></label>
                <div class="needsclick dropzone <?php echo e($errors->has('attachment') ? 'is-invalid' : ''); ?>" id="attachment-dropzone">
                </div>
                <?php if($errors->has('attachment')): ?>
                    <span class="text-danger"><?php echo e($errors->first('attachment')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.task.fields.attachment_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="due_date"><?php echo e(trans('cruds.task.fields.due_date')); ?></label>
                <input class="form-control date <?php echo e($errors->has('due_date') ? 'is-invalid' : ''); ?>" type="text" name="due_date" id="due_date" value="<?php echo e(old('due_date')); ?>">
                <?php if($errors->has('due_date')): ?>
                    <span class="text-danger"><?php echo e($errors->first('due_date')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.task.fields.due_date_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="assigned_to_id"><?php echo e(trans('cruds.task.fields.assigned_to')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('assigned_to') ? 'is-invalid' : ''); ?>" name="assigned_to_id" id="assigned_to_id">
                    <?php $__currentLoopData = $assigned_tos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e(old('assigned_to_id') == $id ? 'selected' : ''); ?>><?php echo e($entry); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('assigned_to')): ?>
                    <span class="text-danger"><?php echo e($errors->first('assigned_to')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.task.fields.assigned_to_helper')); ?></span>
            </div>
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    <?php echo e(trans('global.save')); ?>

                </button>
            </div>
        </form>
    </div>
</div>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    Dropzone.options.attachmentDropzone = {
    url: '<?php echo e(route('admin.tasks.storeMedia')); ?>',
    maxFilesize: 2, // MB
    maxFiles: 1,
    addRemoveLinks: true,
    headers: {
      'X-CSRF-TOKEN': "<?php echo e(csrf_token()); ?>"
    },
    params: {
      size: 2
    },
    success: function (file, response) {
      $('form').find('input[name="attachment"]').remove()
      $('form').append('<input type="hidden" name="attachment" value="' + response.name + '">')
    },
    removedfile: function (file) {
      file.previewElement.remove()
      if (file.status !== 'error') {
        $('form').find('input[name="attachment"]').remove()
        this.options.maxFiles = this.options.maxFiles + 1
      }
    },
    init: function () {
<?php if(isset($task) && $task->attachment): ?>
      var file = <?php echo json_encode($task->attachment); ?>

          this.options.addedfile.call(this, file)
      file.previewElement.classList.add('dz-complete')
      $('form').append('<input type="hidden" name="attachment" value="' + file.file_name + '">')
      this.options.maxFiles = this.options.maxFiles - 1
<?php endif; ?>
    },
     error: function (file, response) {
         if ($.type(response) === 'string') {
             var message = response //dropzone sends it's own error messages in string
         } else {
             var message = response.errors.file
         }
         file.previewElement.classList.add('dz-error')
         _ref = file.previewElement.querySelectorAll('[data-dz-errormessage]')
         _results = []
         for (_i = 0, _len = _ref.length; _i < _len; _i++) {
             node = _ref[_i]
             _results.push(node.textContent = message)
         }

         return _results
     }
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\crm\resources\views/admin/tasks/create.blade.php ENDPATH**/ ?>