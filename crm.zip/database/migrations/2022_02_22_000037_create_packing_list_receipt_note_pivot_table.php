<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreatePackingListReceiptNotePivotTable extends Migration
{
    public function up()
    {
        Schema::create('packing_list_receipt_note', function (Blueprint $table) {
            $table->unsignedBigInteger('packing_list_id');
            $table->foreign('packing_list_id', 'packing_list_id_fk_6051544')->references('id')->on('packing_lists')->onDelete('cascade');
            $table->unsignedBigInteger('receipt_note_id');
            $table->foreign('receipt_note_id', 'receipt_note_id_fk_6051544')->references('id')->on('receipt_notes')->onDelete('cascade');
        });
    }
}
