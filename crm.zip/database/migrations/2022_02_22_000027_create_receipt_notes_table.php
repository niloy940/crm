<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateReceiptNotesTable extends Migration
{
    public function up()
    {
        Schema::create('receipt_notes', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->float('quantity', 8, 3);
            $table->string('lot');
            $table->string('int_lot');
            $table->string('qc');
            $table->string('shift');
            $table->date('date');
            $table->string('place');
            $table->string('driver');
            $table->string('id_driver');
            $table->string('registration');
            $table->string('print')->nullable();
            $table->timestamps();
            $table->softDeletes();
        });
    }
}
