<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Controllers\Traits\CsvImportTrait;
use App\Http\Requests\MassDestroyIdentificationCardRequest;
use App\Http\Requests\StoreIdentificationCardRequest;
use App\Http\Requests\UpdateIdentificationCardRequest;
use App\Models\IdentificationCard;
use App\Models\ProductsList;
use App\Models\ReceiptNote;
use App\Models\Team;
use Gate;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use Yajra\DataTables\Facades\DataTables;

class IdentificationCardController extends Controller
{
    use CsvImportTrait;

    public function index(Request $request)
    {
        abort_if(Gate::denies('identification_card_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        if ($request->ajax()) {
            $query = IdentificationCard::with(['product', 'lot', 'team'])->select(sprintf('%s.*', (new IdentificationCard())->table));
            $table = Datatables::of($query);

            $table->addColumn('placeholder', '&nbsp;');
            $table->addColumn('actions', '&nbsp;');

            $table->editColumn('actions', function ($row) {
                $viewGate = 'identification_card_show';
                $editGate = 'identification_card_edit';
                $deleteGate = 'identification_card_delete';
                $crudRoutePart = 'identification-cards';

                return view('partials.datatablesActions', compact(
                'viewGate',
                'editGate',
                'deleteGate',
                'crudRoutePart',
                'row'
            ));
            });

            $table->editColumn('id', function ($row) {
                return $row->id ? $row->id : '';
            });
            $table->addColumn('product_name', function ($row) {
                return $row->product ? $row->product->name : '';
            });

            $table->editColumn('quantity', function ($row) {
                return $row->quantity ? $row->quantity : '';
            });
            $table->addColumn('lot_lot', function ($row) {
                return $row->lot ? $row->lot->lot : '';
            });

            $table->editColumn('int_lot', function ($row) {
                return $row->int_lot ? $row->int_lot : '';
            });
            $table->editColumn('storage_cond', function ($row) {
                return $row->storage_cond ? $row->storage_cond : '';
            });

            $table->rawColumns(['actions', 'placeholder', 'product', 'lot']);

            return $table->make(true);
        }

        $products_lists = ProductsList::get();
        $receipt_notes  = ReceiptNote::get();
        $teams          = Team::get();

        return view('admin.identificationCards.index', compact('products_lists', 'receipt_notes', 'teams'));
    }

    public function create()
    {
        abort_if(Gate::denies('identification_card_create'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $products = ProductsList::pluck('name', 'id')->prepend(trans('global.pleaseSelect'), '');

        $lots = ReceiptNote::pluck('lot', 'id')->prepend(trans('global.pleaseSelect'), '');

        return view('admin.identificationCards.create', compact('lots', 'products'));
    }

    public function store(StoreIdentificationCardRequest $request)
    {
        $identificationCard = IdentificationCard::create($request->all());

        return redirect()->route('admin.identification-cards.index');
    }

    public function edit(IdentificationCard $identificationCard)
    {
        abort_if(Gate::denies('identification_card_edit'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $products = ProductsList::pluck('name', 'id')->prepend(trans('global.pleaseSelect'), '');

        $lots = ReceiptNote::pluck('lot', 'id')->prepend(trans('global.pleaseSelect'), '');

        $identificationCard->load('product', 'lot', 'team');

        return view('admin.identificationCards.edit', compact('identificationCard', 'lots', 'products'));
    }

    public function update(UpdateIdentificationCardRequest $request, IdentificationCard $identificationCard)
    {
        $identificationCard->update($request->all());

        return redirect()->route('admin.identification-cards.index');
    }

    public function show(IdentificationCard $identificationCard)
    {
        abort_if(Gate::denies('identification_card_show'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $identificationCard->load('product', 'lot', 'team');

        return view('admin.identificationCards.show', compact('identificationCard'));
    }

    public function destroy(IdentificationCard $identificationCard)
    {
        abort_if(Gate::denies('identification_card_delete'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $identificationCard->delete();

        return back();
    }

    public function massDestroy(MassDestroyIdentificationCardRequest $request)
    {
        IdentificationCard::whereIn('id', request('ids'))->delete();

        return response(null, Response::HTTP_NO_CONTENT);
    }
}
