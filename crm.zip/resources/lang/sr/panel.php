<?php

return [
    'site_title' => 'My Spoon',
];
